cmd_/home/mama/peak_build/peak_usb.o := ld -EL  -maarch64elf -z noexecstack   -r -o /home/mama/peak_build/peak_usb.o @/home/mama/peak_build/peak_usb.mod
