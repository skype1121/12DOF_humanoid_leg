cmd_/home/mama/peak_build/Module.symvers := sed 's/\.ko$$/\.o/' /home/mama/peak_build/modules.order | scripts/mod/modpost -m   -o /home/mama/peak_build/Module.symvers -e -i Module.symvers   -T -
