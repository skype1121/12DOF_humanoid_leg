#!/usr/bin/env python3

import json
import time

import rclpy
from rclpy.node import Node
from smbus import SMBus
from std_msgs.msg import String


# Jetson 40핀 3번/5번에 연결된 I2C 버스
I2C_BUS = 7

# 왼발 ADS1115, 오른발 ADS1115
ADS_ADDRESSES = (0x48, 0x49)

REG_CONVERSION = 0x00
REG_CONFIG = 0x01

# ADS1115 단일 입력 A0~A3
MUX_SINGLE = (
    0x4000,  # A0 - GND
    0x5000,  # A1 - GND
    0x6000,  # A2 - GND
    0x7000,  # A3 - GND
)

# ADS1115 설정
# OS   : 단일 변환 시작
# PGA  : ±4.096V
# MODE : single-shot
# DR   : 128 SPS
# COMP : 비교기 비활성화
BASE_CONFIG = (
    0x8000
    | 0x0200
    | 0x0100
    | 0x0080
    | 0x0003
)

ADS_FULL_SCALE_VOLTAGE = 4.096
SENSOR_SUPPLY_VOLTAGE = 3.3
PUBLISH_HZ = 10.0


class PressureSerialNode(Node):
    def __init__(self):
        super().__init__('pressure_serial_node')

        self.publisher = self.create_publisher(
            String,
            '/humanoid/pressure/data',
            10,
        )

        self.bus = SMBus(I2C_BUS)
        self.error_count = 0

        self.timer = self.create_timer(
            1.0 / PUBLISH_HZ,
            self.publish_pressure_data,
        )

        self.get_logger().info(
            'ADS1115 pressure node started: '
            '/dev/i2c-7, addresses 0x48/0x49'
        )
        self.get_logger().info(
            '0x48 A0~A3 = left, 0x49 A0~A3 = right'
        )
        self.get_logger().info(
            'Publishing: /humanoid/pressure/data'
        )

    def read_ads1115_channel(self, address, channel):
        config = BASE_CONFIG | MUX_SINGLE[channel]

        self.bus.write_i2c_block_data(
            address,
            REG_CONFIG,
            [
                (config >> 8) & 0xFF,
                config & 0xFF,
            ],
        )

        # 128 SPS 변환 시간은 약 7.8ms
        time.sleep(0.010)

        data = self.bus.read_i2c_block_data(
            address,
            REG_CONVERSION,
            2,
        )

        raw_signed = (data[0] << 8) | data[1]

        if raw_signed & 0x8000:
            raw_signed -= 65536

        # 단일 입력에서 나타나는 작은 음수 노이즈 제거
        raw = max(0, raw_signed)

        voltage = (
            raw
            * ADS_FULL_SCALE_VOLTAGE
            / 32768.0
        )

        # 기존 Arduino ADC와 같은 0~1023 범위
        value_10bit = round(
            voltage
            / SENSOR_SUPPLY_VOLTAGE
            * 1023.0
        )

        value_10bit = max(
            0,
            min(1023, value_10bit),
        )

        return raw, voltage, value_10bit

    def read_all_channels(self):
        raw_values = []
        voltages = []
        values_10bit = []

        for address in ADS_ADDRESSES:
            for channel in range(4):
                raw, voltage, value_10bit = (
                    self.read_ads1115_channel(
                        address,
                        channel,
                    )
                )

                raw_values.append(raw)
                voltages.append(round(voltage, 4))
                values_10bit.append(value_10bit)

        return raw_values, voltages, values_10bit

    def publish_pressure_data(self):
        try:
            raw_values, voltages, values = (
                self.read_all_channels()
            )

            now = self.get_clock().now().to_msg()

            payload = {
                'timestamp': (
                    now.sec
                    + now.nanosec / 1_000_000_000.0
                ),
                'source': 'ads1115_i2c',
                'values': values,
                'left': values[0:4],
                'right': values[4:8],
                'raw_ads1115': raw_values,
                'voltages': voltages,
            }

            message = String()
            message.data = json.dumps(
                payload,
                ensure_ascii=False,
                separators=(',', ':'),
            )

            self.publisher.publish(message)
            self.error_count = 0

        except OSError as error:
            self.error_count += 1

            # 터미널에 오류가 너무 많이 출력되지 않도록 제한
            if self.error_count == 1 or self.error_count % 20 == 0:
                self.get_logger().error(
                    f'ADS1115 I2C read failed: {error}'
                )

        except Exception as error:
            self.get_logger().error(
                f'Pressure node error: {error}'
            )

    def destroy_node(self):
        try:
            self.bus.close()
        except Exception:
            pass

        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)

    node = None

    try:
        node = PressureSerialNode()
        rclpy.spin(node)

    except KeyboardInterrupt:
        pass

    finally:
        if node is not None:
            node.destroy_node()

        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
