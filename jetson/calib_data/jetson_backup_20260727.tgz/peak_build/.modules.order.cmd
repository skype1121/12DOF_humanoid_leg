cmd_/home/mama/peak_build/modules.order := {   echo /home/mama/peak_build/peak_usb.ko; :; } | awk '!x[$$0]++' - > /home/mama/peak_build/modules.order
