#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x24d702c7, "module_layout" },
	{ 0x8feb96b0, "netdev_info" },
	{ 0x9f703e67, "kmalloc_caches" },
	{ 0xeb233a45, "__kmalloc" },
	{ 0x1fdc7df2, "_mcount" },
	{ 0x26bae506, "register_candev" },
	{ 0x40729c4a, "alloc_can_err_skb" },
	{ 0xb43f9365, "ktime_get" },
	{ 0x1fbfbdab, "driver_for_each_device" },
	{ 0xc6f46339, "init_timer_key" },
	{ 0x15ba50a6, "jiffies" },
	{ 0xb0ed58a8, "usb_unanchor_urb" },
	{ 0x8c4f11c4, "can_bus_off" },
	{ 0x661c0b12, "netif_rx" },
	{ 0xd9a5ea54, "__init_waitqueue_head" },
	{ 0x95df6106, "_dev_warn" },
	{ 0xdcb764ad, "memset" },
	{ 0xf7dd6035, "close_candev" },
	{ 0x91bdaa4c, "netif_tx_wake_queue" },
	{ 0x25cc9e82, "usb_deregister" },
	{ 0xf12d9387, "can_fd_dlc2len" },
	{ 0xa2645617, "usb_control_msg" },
	{ 0x54740038, "kfree_skb_reason" },
	{ 0x6047ede6, "can_fd_len2dlc" },
	{ 0x1708e5a8, "alloc_candev_mqs" },
	{ 0xc38c83b8, "mod_timer" },
	{ 0x6c2e5b8, "free_candev" },
	{ 0xc42c119c, "_dev_err" },
	{ 0x167c5967, "print_hex_dump" },
	{ 0xc9edd5c5, "can_change_mtu" },
	{ 0xe91b602c, "can_change_state" },
	{ 0x845d17cc, "_dev_info" },
	{ 0xb3142616, "usb_submit_urb" },
	{ 0x4c9f0cc0, "unregister_candev" },
	{ 0x1ea45baf, "netif_device_detach" },
	{ 0xa916b694, "strnlen" },
	{ 0x962c8ae1, "usb_kill_anchored_urbs" },
	{ 0x6cee23fd, "alloc_can_skb" },
	{ 0x3ea1b6e4, "__stack_chk_fail" },
	{ 0xec326b98, "usb_bulk_msg" },
	{ 0x8ddd8aad, "schedule_timeout" },
	{ 0x92997ed8, "_printk" },
	{ 0x31909811, "cpu_hwcap_keys" },
	{ 0x4a1ce9a1, "netdev_err" },
	{ 0xcbd4898c, "fortify_panic" },
	{ 0x2ebe9537, "open_candev" },
	{ 0xf9873a52, "kmem_cache_alloc_trace" },
	{ 0xf6ebc03b, "net_ratelimit" },
	{ 0x33f0fae6, "netdev_warn" },
	{ 0x37a0cba, "kfree" },
	{ 0x4829a47e, "memcpy" },
	{ 0x379d1f1c, "usb_register_driver" },
	{ 0x7cace5a, "alloc_canfd_skb" },
	{ 0xa37786bf, "unregister_netdev" },
	{ 0x80cd7e8a, "can_get_echo_skb" },
	{ 0x666c3935, "consume_skb" },
	{ 0x9f32536, "can_put_echo_skb" },
	{ 0x6e95ac0a, "can_free_echo_skb" },
	{ 0x14b89635, "arm64_const_caps_ready" },
	{ 0x79a0e532, "usb_free_urb" },
	{ 0x14ca4fe6, "usb_anchor_urb" },
	{ 0xdfcff954, "usb_alloc_urb" },
};

MODULE_INFO(depends, "can-dev");

MODULE_ALIAS("usb:v0C72p000Cd*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0C72p000Dd*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0C72p0012d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0C72p0011d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0C72p0013d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0C72p0014d*dc*dsc*dp*ic*isc*ip*in*");
