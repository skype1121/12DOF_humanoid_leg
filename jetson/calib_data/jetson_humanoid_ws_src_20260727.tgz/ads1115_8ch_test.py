#!/usr/bin/env python3

import os
import time
from smbus import SMBus


I2C_BUS = 7
ADS_ADDRESSES = [0x48, 0x49]

REG_CONVERSION = 0x00
REG_CONFIG = 0x01

MUX_SINGLE = [
    0x4000,  # A0 - GND
    0x5000,  # A1 - GND
    0x6000,  # A2 - GND
    0x7000,  # A3 - GND
]

# 단일 변환 시작
# 입력 범위: ±4.096V
# Single-shot 모드
# 데이터 속도: 128 SPS
# 비교기 비활성화
BASE_CONFIG = (
    0x8000
    | 0x0200
    | 0x0100
    | 0x0080
    | 0x0003
)


def read_channel(bus, address, channel):
    config = BASE_CONFIG | MUX_SINGLE[channel]

    bus.write_i2c_block_data(
        address,
        REG_CONFIG,
        [
            (config >> 8) & 0xFF,
            config & 0xFF,
        ],
    )

    # ADS1115 변환 대기
    time.sleep(0.01)

    data = bus.read_i2c_block_data(
        address,
        REG_CONVERSION,
        2,
    )

    raw = (data[0] << 8) | data[1]

    if raw & 0x8000:
        raw -= 65536

    voltage = raw * 4.096 / 32768.0

    return raw, voltage


def main():
    bus = SMBus(I2C_BUS)

    try:
        while True:
            values = []

            for address in ADS_ADDRESSES:
                for channel in range(4):
                    try:
                        raw, voltage = read_channel(
                            bus,
                            address,
                            channel,
                        )

                        values.append(
                            {
                                "address": address,
                                "channel": channel,
                                "raw": raw,
                                "voltage": voltage,
                                "error": None,
                            }
                        )

                    except OSError as error:
                        values.append(
                            {
                                "address": address,
                                "channel": channel,
                                "raw": 0,
                                "voltage": 0.0,
                                "error": str(error),
                            }
                        )

            os.system("clear")

            print("==========================================")
            print("       ADS1115 압력센서 8채널 테스트")
            print("==========================================")
            print(f"I2C 버스 : /dev/i2c-{I2C_BUS}")
            print("ADS1115  : 0x48, 0x49")
            print("종료     : Ctrl+C")
            print()
            print("채널             RAW       전압")
            print("------------------------------------------")

            for value in values:
                address = value["address"]
                channel = value["channel"]

                if value["error"] is None:
                    print(
                        f"0x{address:02X} A{channel}"
                        f"       {value['raw']:7d}"
                        f"     {value['voltage']:7.4f} V"
                    )
                else:
                    print(
                        f"0x{address:02X} A{channel}"
                        f"       통신 오류: {value['error']}"
                    )

            print("------------------------------------------")
            print("압력센서를 누르면서 RAW와 전압 변화를 확인하세요.")

            time.sleep(0.2)

    except KeyboardInterrupt:
        print("\nADS1115 테스트를 종료합니다.")

    finally:
        bus.close()


if __name__ == "__main__":
    main()
