from setuptools import find_packages, setup

package_name = "humanoid_pressure"

setup(
    name=package_name,
    version="0.0.1",
    packages=find_packages(exclude=["test"]),
    data_files=[
        (
            "share/ament_index/resource_index/packages",
            ["resource/" + package_name],
        ),
        (
            "share/" + package_name,
            ["package.xml"],
        ),
    ],
    install_requires=["setuptools"],
    zip_safe=True,
    maintainer="mama",
    maintainer_email="mama@todo.todo",
    description="Arduino Mega pressure sensor serial ROS 2 node",
    license="Apache-2.0",
    entry_points={
        "console_scripts": [
            "pressure_serial_node = humanoid_pressure.pressure_serial_node:main",
        ],
    },
)
