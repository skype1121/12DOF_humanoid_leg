import math
import time

import rclpy
from rclpy.executors import ExternalShutdownException
from rclpy.node import Node
from sensor_msgs.msg import Imu

import serial


GRAVITY = 9.80665


def euler_deg_to_quaternion(roll_deg, pitch_deg, yaw_deg):
    """Roll, Pitch, Yaw(deg)를 Quaternion으로 변환한다."""

    roll = math.radians(roll_deg)
    pitch = math.radians(pitch_deg)
    yaw = math.radians(yaw_deg)

    cr = math.cos(roll * 0.5)
    sr = math.sin(roll * 0.5)
    cp = math.cos(pitch * 0.5)
    sp = math.sin(pitch * 0.5)
    cy = math.cos(yaw * 0.5)
    sy = math.sin(yaw * 0.5)

    qx = sr * cp * cy - cr * sp * sy
    qy = cr * sp * cy + sr * cp * sy
    qz = cr * cp * sy - sr * sp * cy
    qw = cr * cp * cy + sr * sp * sy

    return qx, qy, qz, qw


class ImuNode(Node):

    def __init__(self):
        super().__init__('imu_node')

        self.declare_parameter('port', '/dev/ttyUSB0')
        self.declare_parameter('baudrate', 115200)
        self.declare_parameter('frame_id', 'imu_link')

        self.port = self.get_parameter('port').value
        self.baudrate = self.get_parameter('baudrate').value
        self.frame_id = self.get_parameter('frame_id').value

        self.publisher_ = self.create_publisher(
            Imu,
            '/humanoid/imu/data',
            10
        )

        self.serial_port = None
        self.rx_buffer = bytearray()
        self.valid_count = 0

        try:
            self.serial_port = serial.Serial(
                port=self.port,
                baudrate=self.baudrate,
                timeout=0
            )
        except serial.SerialException as error:
            self.get_logger().fatal(
                f'iAHRS serial open failed: {error}'
            )
            raise

        self.serial_port.reset_input_buffer()
        self.serial_port.reset_output_buffer()

        # iAHRS 연속 출력 설정
        for command in ('so=1\n', 'sp=10\n', 'sd=0x005C\n'):
            self.serial_port.write(command.encode('ascii'))
            self.serial_port.flush()
            time.sleep(0.1)

        self.timer = self.create_timer(0.005, self.read_serial)

        self.get_logger().info(
            f'iAHRS connected: {self.port} @ {self.baudrate} bps'
        )
        self.get_logger().info(
            'Publishing actual IMU data: /humanoid/imu/data'
        )

    def read_serial(self):
        try:
            waiting = self.serial_port.in_waiting

            if waiting <= 0:
                return

            self.rx_buffer.extend(
                self.serial_port.read(waiting)
            )

        except serial.SerialException as error:
            self.get_logger().error(
                f'iAHRS serial read failed: {error}'
            )
            self.timer.cancel()
            return

        while b'\n' in self.rx_buffer:
            raw_line, _, remaining = self.rx_buffer.partition(b'\n')
            self.rx_buffer = bytearray(remaining)

            line = raw_line.decode(
                'ascii',
                errors='ignore'
            ).strip()

            if line:
                self.parse_and_publish(line)

    def parse_and_publish(self, line):
        parts = [value.strip() for value in line.split(',')]

        # 명령 응답 so=1, sp=10 등은 무시한다.
        if len(parts) != 12:
            return

        try:
            values = [float(value) for value in parts]
        except ValueError:
            return

        (
            accel_x_g,
            accel_y_g,
            accel_z_g,
            gyro_x_deg_s,
            gyro_y_deg_s,
            gyro_z_deg_s,
            _mag_x,
            _mag_y,
            _mag_z,
            roll_deg,
            pitch_deg,
            yaw_deg,
        ) = values

        qx, qy, qz, qw = euler_deg_to_quaternion(
            roll_deg,
            pitch_deg,
            yaw_deg
        )

        msg = Imu()

        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = self.frame_id

        # 자세: Quaternion
        msg.orientation.x = qx
        msg.orientation.y = qy
        msg.orientation.z = qz
        msg.orientation.w = qw

        # 각속도: deg/s → rad/s
        msg.angular_velocity.x = math.radians(gyro_x_deg_s)
        msg.angular_velocity.y = math.radians(gyro_y_deg_s)
        msg.angular_velocity.z = math.radians(gyro_z_deg_s)

        # 가속도: g → m/s²
        msg.linear_acceleration.x = accel_x_g * GRAVITY
        msg.linear_acceleration.y = accel_y_g * GRAVITY
        msg.linear_acceleration.z = accel_z_g * GRAVITY

        self.publisher_.publish(msg)

        self.valid_count += 1

        if self.valid_count % 20 == 0:
            self.get_logger().info(
                f'RX={self.valid_count} | '
                f'Roll={roll_deg:.2f}° | '
                f'Pitch={pitch_deg:.2f}° | '
                f'Yaw={yaw_deg:.2f}°'
            )

    def destroy_node(self):
        if (
            self.serial_port is not None
            and self.serial_port.is_open
        ):
            try:
                self.serial_port.write(b'so=0\n')
                self.serial_port.flush()
            except serial.SerialException:
                pass

            self.serial_port.close()

        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    node = None

    try:
        node = ImuNode()
        rclpy.spin(node)

    except (KeyboardInterrupt, ExternalShutdownException):
        pass

    except serial.SerialException as error:
        print(f'iAHRS serial error: {error}')

    finally:
        if node is not None:
            node.destroy_node()

        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
